# Securerise: Universal Trust Layer for Emerging Markets

**Powered by AI-Augmented Escrow & Bank-Grade Ledger Precision**

## Vision

Securerise builds the **Universal Trust Layer** for high-value peer-to-peer asset exchange in Kenya, East Africa, and emerging markets. We solve the "Trust Gap"—the friction between payment and physical delivery—by combining Computer Vision AI with immutable escrow handshakes. Our platform enables agribusiness, fintech, and logistics providers to automate secure transactions across MPESA, bank rails, and USDC.

## The Problem

- Informal asset traders lose 15-30% to fraud and payment disputes
- Buyers cannot verify physical goods before releasing funds
- Sellers face delayed payments due to manual inspection processes
- Traditional escrow requires expensive intermediaries

## The Solution

Securerise introduces a **programmable trust boundary**:

1. **Create** an immutable escrow handshake (UUID-based, ledger-backed)
2. **Upload** proof-of-delivery image for AI inspection
3. **Verify** asset match using Gemini 1.5 Flash multimodal AI
4. **Release** funds automatically when confidence threshold met

## Core Engine: High-Precision Validation

### BigInt Ledger Precision
All monetary transactions use 64-bit BigInt for cent-level accuracy—eliminating floating-point errors common in fintech systems:
```typescript
// Bank-grade: 125050 KES cents (1250.50 KES) stored as precise bigint
const amountKESCents: bigint = 125050n;
// Zero risk of decimal drift
```

### Handshake State Machine
```
INITIATED → LOCKED → AI_VERIFYING → RELEASED
                  ↘
                   → REFUNDED (failed verification)
```

Each transition is immutable and audit-logged via PostgreSQL triggers.

## Architecture

**Stack:**
- **Runtime**: Node.js 20+ with TypeScript 6.0
- **Database**: PostgreSQL with Prisma ORM (BigInt support)
- **AI**: Gemini 1.5 Flash on Google Cloud (multimodal, < 2s response)
- **API Gateway**: Express.js with tenant-aware routing
- **Security**: Helmet, CORS, x-api-key middleware
- **OS**: Hardened Parrot OS for security-focused deployment

**Modularity:**
```
src/
├── index.ts          # Entry point & bootstrap
├── app.ts            # Express config (BigInt polyfill, middleware)
├── routes/api.ts     # Handshake router (/v1/handshakes)
├── controllers/      # Business logic
├── services/         # AI integration & escrow engine
└── middleware/       # Auth & security
```

## Setup Instructions

### Prerequisites
- **Node.js** v20+ ([https://nodejs.org](https://nodejs.org))
- **PostgreSQL** instance (local or remote)
- **Gemini API Key** from [Google AI Studio](https://aistudio.google.com)

### Quick Start for Technical Auditors

```bash
# 1. Clone
git clone https://github.com/jjaokoth/securerise.git
cd securerise

# 2. Install dependencies
npm install

# 3. Configure environment
cp .env.example .env
# Edit .env with:
# - DATABASE_URL=postgresql://user:password@localhost:5432/securerise
# - GEMINI_API_KEY=<your_gemini_key>
# - INTERNAL_API_KEY=<strong_random_string>

# 4. Sync database schema
npx prisma generate
npx prisma db push

# 5. Launch development server (auto-restart on changes)
npm run dev
```

**Server runs on**: `http://localhost:3000`

### Production Build
```bash
npm run build
npm start
```

## API Reference

### POST /v1/handshakes
Create an immutable escrow handshake.

**Headers:** `x-api-key: <tenant_api_key>`

**Request:**
```json
{
  "amountKESCents": "125000",
  "amountUSDCents": "10000",
  "exchangeRateKESPerUSDC": "1250000",
  "route": "MPESA",
  "handshakeMetadata": {
    "itemDescription": "Mercedes W123 Headlights (Part ABC-123)"
  }
}
```

**Response:**
```json
{
  "handshakeId": "hs_e4d7c9f2-1234",
  "status": "OPEN",
  "escrow_address": "escrow_xyz789",
  "evidenceUploadUrl": "/api/payout/handshakes/hs_e4d7c9f2-1234/verify-proof"
}
```

### POST /v1/handshakes/:id/verify
Submit proof-of-delivery image for AI verification.

**Headers:** `x-api-key: <tenant_api_key>`  
**Content-Type:** `multipart/form-data`  
**Body:** `image` (JPEG/PNG, max 10MB)

**Response:**
```json
{
  "verification": {
    "isMatch": true,
    "confidence": 0.94,
    "extractedDetails": "Part #ABC-123 verified. No damage detected.",
    "issueDetected": false
  },
  "mappedStatus": "RELEASED",
  "statusLabel": "AI_VERIFIED"
}
```

## Security & Compliance

- ✅ **Helmet.js** active: XSS, CSRF, Clickjacking protections
- ✅ **CORS** configured for institutional partners
- ✅ **x-api-key** validation against hashed tenant keys (SHA-256)
- ✅ **BigInt serialization** prevents JSON overflow attacks
- ✅ **No hardcoded secrets**: All credentials via `.env`
- ✅ **Audit logging**: Every handshake transition recorded

## License

**Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International (CC BY-NC-ND 4.0)**

This repository is a proprietary technical showcase. Unauthorized commercial use is prohibited. Production deployment requires a commercial license from Securerise Solutions Limited.

See [LICENSE](./LICENSE) file for full terms.

## Contact & Investment

**Lead Architect**: Joshua Joel A Okoth  
**Email**: securerise@outlook.com  

For partnership, investment inquiries, and commercial licensing:
- 📧 Email: securerise@outlook.com
- 🔗 GitHub: [github.com/jjaokoth/securerise](https://github.com/jjaokoth/securerise)

---

**Securerise Solutions Limited**  
*Building Trust in Emerging Markets*

```
src/
├── index.ts          # Entry point
├── app.ts            # Express config & middleware
├── routes/api.ts     # Handshake routes
├── controllers/      # Business logic
├── services/         # AI & escrow services
└── middleware/       # Auth & security
```

## Funding-Ready Metrics

- Targets multi-billion-shilling Kenyan asset trading market.
- Reduces fraud through AI verification.
- Supports concurrent handshakes with sub-second AI responses.

## Contact

For partnerships or investment inquiries: [contact@jjaokoth.com](mailto:contact@jjaokoth.com)

## Why this matters

Securerise is not just an escrow service. It is a Universal Trust Layer built to solve the multi-billion-dollar trust gap in Kenya’s informal asset markets, where fraud and non-delivery routinely plague transactions for items like mobile phones, spare parts, and even Mercedes headlights.

In markets where buyers cannot reliably verify physical delivery before sending funds, Securerise introduces a programmable boundary between payment and proof-of-delivery. This means an AI-verified handshake must succeed before funds flow into MPESA, BANK, or USDC rails.

## The business case

- Problem: informal Kenyan asset trading is exposed to systemic fraud and trust erosion.
- Opportunity: enable secure, automated payments for offline and online goods through escrow-backed verification.
- Differentiator: Securerise pairs AI Vision proof-of-delivery with immutable escrow handshakes, creating a trust layer across MPESA, BANK, and USDC.

This platform is designed for institutional partners, digital marketplaces, and logistics providers that want a measurable reduction in disputes and a defensible edge over existing cash-on-delivery and manual release models.

## What it does

Securerise allows providers to:

- Create a `LOCKED` payment handshake for a transaction.
- Submit an image as proof-of-delivery.
- Let the AI Vision verifier inspect the asset and metadata.
- Automatically release funds only when confidence is high.

This is especially powerful for high-risk use cases like vehicle parts, electronics, and cross-border payments.

## Architecture

```mermaid
flowchart TD
  A[Buyer / Seller Marketplace] -->|create escrow handshake| B[API Gateway /v1/handshakes]
  B --> C[Prisma-backed Trust Ledger]
  B --> D[AI Vision Verifier]
  D -->|confidence score| E[Escrow Handshake Engine]
  E -->|release funds| F[MPESA / BANK / USDC Rails]
  G[Seller] -->|upload proof image| B
  G -->|metadata + order ref| B
  D --> H[AI Vision API]
  H -->|asset identity verification| D
```

### Key flows

1. `POST /v1/handshakes` creates a universal escrow handshake with metadata and routing instructions.
2. `POST /v1/handshakes/{id}/verify` submits proof-of-delivery via image upload.
3. The system updates handshake state to `RELEASED` or `FAILED` based on AI confidence.

## API documentation highlights

Securerise exposes clean, versioned endpoints for technical partners and VC scouts.

### Create a handshake

- Endpoint: `POST /v1/handshakes`
- Security: `x-api-key`
- Payload: `route`, `amountKESCents`, `amountUSDCents`, `exchangeRateKESPerUSDC`, `handshakeMetadata`
- Output: `handshakeId`, `status`, `escrow_address`, `evidenceUploadUrl`

### Verify proof-of-delivery

- Endpoint: `POST /v1/handshakes/{id}/verify`
- Security: `x-api-key`
- Payload: `multipart/form-data` image upload field `image`
- Output: `verification`, `mappedStatus`, `statusLabel`

### Status semantics

- `LOCKED`: payment is reserved and awaiting delivery proof.
- `RELEASED`: proof accepted, payout execution can proceed.
- `DISPUTED`: verification was inconclusive and requires audit.
- `FAILED`: proof rejected or suspicious.

## Investor-ready value props

- AI-enabled trust: reduces fraud in high-risk physical asset trades.
- Multi-rail payout: supports MPESA, bank rails, and USDC.
- Immutable handshakes: every transaction is captured in a single escrow intent ledger.
- Developer-friendly: versioned API + OpenAPI contract in `openapi/openapi.yaml`.

## Technical foundation

- Node.js + Express API gateway
- Prisma ORM for a structured escrow ledger
- AI Vision verification service for proof-of-delivery
- Tenant-aware `x-api-key` authentication
- Modular controller and service architecture for rapid iteration

## Getting started

```bash
git clone https://github.com/jjaokoth/securerise.git
cd securerise
npm install
cp .env.example .env
```

Then run:

```bash
npm start
```

## Where the docs live

The API contract is defined in `openapi/openapi.yaml`, including the core handshake creation and verification endpoints.
