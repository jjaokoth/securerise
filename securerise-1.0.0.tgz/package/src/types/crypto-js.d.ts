declare module 'crypto-js';

